﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Command {
    public GameObject target;
    public float executeTime=0f;

	void ExeCute()
    {
        
    }
}
